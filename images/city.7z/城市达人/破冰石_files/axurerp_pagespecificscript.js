﻿
var PageName = '破冰石';
var PageId = 'bf5ccd1eee4b4fd8ba33f9c9b12e60f7'
var PageUrl = '破冰石.html'
document.title = '破冰石';
var PageNotes = {};

if (window.OnLoad) OnLoad();
